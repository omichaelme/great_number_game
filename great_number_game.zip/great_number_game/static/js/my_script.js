alert("It's Random Number Game!");
